﻿namespace Atividade3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtPeso = new TextBox();
            txtAltura = new TextBox();
            btnCalcularImc = new Button();
            txtClassification = new TextBox();
            txtObesityDegree = new TextBox();
            lblWeight = new Label();
            lblHeight = new Label();
            lblClassification = new Label();
            lblObesityDegree = new Label();
            lblImc = new Label();
            txtImc = new TextBox();
            SuspendLayout();
            // 
            // txtPeso
            // 
            txtPeso.Location = new Point(389, 69);
            txtPeso.Name = "txtPeso";
            txtPeso.Size = new Size(297, 31);
            txtPeso.TabIndex = 1;
            txtPeso.Validated += txtPeso_Validated;
            // 
            // txtAltura
            // 
            txtAltura.Location = new Point(389, 138);
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new Size(297, 31);
            txtAltura.TabIndex = 2;
            txtAltura.Validated += txtAltura_Validated;
            // 
            // btnCalcularImc
            // 
            btnCalcularImc.Location = new Point(477, 400);
            btnCalcularImc.Name = "btnCalcularImc";
            btnCalcularImc.Size = new Size(112, 34);
            btnCalcularImc.TabIndex = 6;
            btnCalcularImc.Text = "Calcular IMC";
            btnCalcularImc.UseVisualStyleBackColor = true;
            btnCalcularImc.Click += btnCalcularImc_Click;
            // 
            // txtClassification
            // 
            txtClassification.BackColor = SystemColors.InactiveCaption;
            txtClassification.Enabled = false;
            txtClassification.Location = new Point(389, 280);
            txtClassification.Name = "txtClassification";
            txtClassification.Size = new Size(297, 31);
            txtClassification.TabIndex = 4;
            // 
            // txtObesityDegree
            // 
            txtObesityDegree.BackColor = SystemColors.InactiveCaption;
            txtObesityDegree.Location = new Point(389, 353);
            txtObesityDegree.Name = "txtObesityDegree";
            txtObesityDegree.Size = new Size(297, 31);
            txtObesityDegree.TabIndex = 5;
            // 
            // lblWeight
            // 
            lblWeight.AutoSize = true;
            lblWeight.Location = new Point(513, 41);
            lblWeight.Name = "lblWeight";
            lblWeight.Size = new Size(49, 25);
            lblWeight.TabIndex = 6;
            lblWeight.Text = "Peso";
            // 
            // lblHeight
            // 
            lblHeight.AutoSize = true;
            lblHeight.Location = new Point(508, 113);
            lblHeight.Name = "lblHeight";
            lblHeight.Size = new Size(59, 25);
            lblHeight.TabIndex = 7;
            lblHeight.Text = "Altura";
            // 
            // lblClassification
            // 
            lblClassification.AutoSize = true;
            lblClassification.Location = new Point(482, 252);
            lblClassification.Name = "lblClassification";
            lblClassification.Size = new Size(111, 25);
            lblClassification.TabIndex = 8;
            lblClassification.Text = "Classificação";
            // 
            // lblObesityDegree
            // 
            lblObesityDegree.AutoSize = true;
            lblObesityDegree.Location = new Point(462, 325);
            lblObesityDegree.Name = "lblObesityDegree";
            lblObesityDegree.Size = new Size(150, 25);
            lblObesityDegree.TabIndex = 9;
            lblObesityDegree.Text = "Obesidade (Grau)";
            // 
            // lblImc
            // 
            lblImc.AutoSize = true;
            lblImc.Location = new Point(515, 176);
            lblImc.Name = "lblImc";
            lblImc.Size = new Size(44, 25);
            lblImc.TabIndex = 11;
            lblImc.Text = "IMC";
            // 
            // txtImc
            // 
            txtImc.BackColor = SystemColors.InactiveCaption;
            txtImc.Enabled = false;
            txtImc.Location = new Point(389, 204);
            txtImc.Name = "txtImc";
            txtImc.Size = new Size(297, 31);
            txtImc.TabIndex = 3;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1122, 566);
            Controls.Add(lblImc);
            Controls.Add(txtImc);
            Controls.Add(lblObesityDegree);
            Controls.Add(lblClassification);
            Controls.Add(lblHeight);
            Controls.Add(lblWeight);
            Controls.Add(txtObesityDegree);
            Controls.Add(txtClassification);
            Controls.Add(btnCalcularImc);
            Controls.Add(txtAltura);
            Controls.Add(txtPeso);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtPeso;
        private TextBox txtAltura;
        private Button btnCalcularImc;
        private TextBox txtClassification;
        private TextBox txtObesityDegree;
        private Label lblWeight;
        private Label lblHeight;
        private Label lblClassification;
        private Label lblObesityDegree;
        private Label lblImc;
        private TextBox txtImc;
    }
}
