namespace Atividade3
{
    public partial class Form1 : Form
    {

        double vlrAltura;
        double vlrPeso;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtPeso_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtImc_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void btnCalcularImc_Click(object sender, EventArgs e)
        {
                    double imc = Math.Round(vlrPeso / (vlrAltura * vlrAltura), 1);
                    string imcClassification;
                    string imcObesityDegree;

                    if (imc < 16.5)
                    {
                        imcClassification = "Magreza";
                        imcObesityDegree = "0";

                        txtClassification.Text = imcClassification;
                        txtObesityDegree.Text = imcObesityDegree;
                        txtImc.Text = imc.ToString();
                    }
                    else if (imc < 24.9)
                    {
                        imcClassification = "Normal";
                        imcObesityDegree = "0";

                        txtClassification.Text = imcClassification;
                        txtObesityDegree.Text = imcObesityDegree;
                        txtImc.Text = imc.ToString();
            }
                    else if (imc < 29.9)
                    {
                        imcClassification = "Sobrepeso";
                        imcObesityDegree = "1";

                        txtClassification.Text = imcClassification;
                        txtObesityDegree.Text = imcObesityDegree;
                        txtImc.Text = imc.ToString();
            }
                    else if (imc < 39.9)
                    {
                        imcClassification = "Obesidade";
                        imcObesityDegree = "2";

                        txtClassification.Text = imcClassification;
                        txtObesityDegree.Text = imcObesityDegree;
                        txtImc.Text = imc.ToString();
            }
                    else
                    {
                        imcClassification = "Obesidade Grave";
                        imcObesityDegree = "3";

                        txtClassification.Text = imcClassification;
                        txtObesityDegree.Text = imcObesityDegree;
                        txtImc.Text = imc.ToString();
            }
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {

           

            {
                if (!double.TryParse(txtPeso.Text, out vlrPeso))
                {
                    MessageBox.Show("Valores inv�lidos");
                    txtPeso.Focus();
                }
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {

            {
                if (!double.TryParse(txtAltura.Text, out vlrAltura))
                {
                    MessageBox.Show("Valores inv�lidos");
                    txtAltura.Focus();
                }
            }
        }
    }
}
