﻿namespace PClasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtMatricula = new TextBox();
            txtSalarioMensal = new TextBox();
            txtNome = new TextBox();
            txtDataEntradaEmpresa = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            btnInstanciaMensalista = new Button();
            btnInstanciaMensalistaComParametros = new Button();
            SuspendLayout();
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(279, 52);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(288, 31);
            txtMatricula.TabIndex = 0;
            // 
            // txtSalarioMensal
            // 
            txtSalarioMensal.Location = new Point(279, 126);
            txtSalarioMensal.Name = "txtSalarioMensal";
            txtSalarioMensal.Size = new Size(288, 31);
            txtSalarioMensal.TabIndex = 1;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(279, 89);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(288, 31);
            txtNome.TabIndex = 2;
            // 
            // txtDataEntradaEmpresa
            // 
            txtDataEntradaEmpresa.Location = new Point(279, 163);
            txtDataEntradaEmpresa.Name = "txtDataEntradaEmpresa";
            txtDataEntradaEmpresa.Size = new Size(288, 31);
            txtDataEntradaEmpresa.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(189, 55);
            label1.Name = "label1";
            label1.Size = new Size(84, 25);
            label1.TabIndex = 4;
            label1.Text = "Matrícula";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(212, 89);
            label2.Name = "label2";
            label2.Size = new Size(61, 25);
            label2.TabIndex = 5;
            label2.Text = "Nome";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(147, 129);
            label3.Name = "label3";
            label3.Size = new Size(126, 25);
            label3.TabIndex = 6;
            label3.Text = "Salário Mensal";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(62, 163);
            label4.Name = "label4";
            label4.Size = new Size(211, 25);
            label4.TabIndex = 7;
            label4.Text = "Data Entrada na Empresa";
            // 
            // btnInstanciaMensalista
            // 
            btnInstanciaMensalista.Location = new Point(62, 279);
            btnInstanciaMensalista.Name = "btnInstanciaMensalista";
            btnInstanciaMensalista.Size = new Size(302, 83);
            btnInstanciaMensalista.TabIndex = 8;
            btnInstanciaMensalista.Text = "Instanciar Mensalista";
            btnInstanciaMensalista.UseVisualStyleBackColor = true;
            btnInstanciaMensalista.Click += btnInstanciaMensalista_Click;
            // 
            // btnInstanciaMensalistaComParametros
            // 
            btnInstanciaMensalistaComParametros.Location = new Point(423, 279);
            btnInstanciaMensalistaComParametros.Name = "btnInstanciaMensalistaComParametros";
            btnInstanciaMensalistaComParametros.Size = new Size(302, 83);
            btnInstanciaMensalistaComParametros.TabIndex = 9;
            btnInstanciaMensalistaComParametros.Text = "Instanciar Mensalista passando parâmetros";
            btnInstanciaMensalistaComParametros.UseVisualStyleBackColor = true;
            btnInstanciaMensalistaComParametros.Click += btnInstanciaMensalistaComParametros_Click;
            // 
            // frmMensalista
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnInstanciaMensalistaComParametros);
            Controls.Add(btnInstanciaMensalista);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtDataEntradaEmpresa);
            Controls.Add(txtNome);
            Controls.Add(txtSalarioMensal);
            Controls.Add(txtMatricula);
            Name = "frmMensalista";
            Text = "frmMensalista";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtMatricula;
        private TextBox txtSalarioMensal;
        private TextBox txtNome;
        private TextBox txtDataEntradaEmpresa;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button btnInstanciaMensalista;
        private Button btnInstanciaMensalistaComParametros;
    }
}