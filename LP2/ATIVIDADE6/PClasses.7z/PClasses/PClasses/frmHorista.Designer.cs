﻿namespace PClasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnInstanciaHorista = new Button();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtDataEntradaEmpresa = new TextBox();
            txtNome = new TextBox();
            txtSalarioHora = new TextBox();
            txtMatricula = new TextBox();
            label5 = new Label();
            txtNumeroHoras = new TextBox();
            label6 = new Label();
            txtDiasDeFaltas = new TextBox();
            SuspendLayout();
            // 
            // btnInstanciaHorista
            // 
            btnInstanciaHorista.Location = new Point(287, 317);
            btnInstanciaHorista.Name = "btnInstanciaHorista";
            btnInstanciaHorista.Size = new Size(288, 83);
            btnInstanciaHorista.TabIndex = 18;
            btnInstanciaHorista.Text = "Instanciar Horista";
            btnInstanciaHorista.UseVisualStyleBackColor = true;
            btnInstanciaHorista.Click += btnInstanciaHorista_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(70, 154);
            label4.Name = "label4";
            label4.Size = new Size(211, 25);
            label4.TabIndex = 17;
            label4.Text = "Data Entrada na Empresa";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(139, 120);
            label3.Name = "label3";
            label3.Size = new Size(142, 25);
            label3.TabIndex = 16;
            label3.Text = "Salário por Hora";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(220, 80);
            label2.Name = "label2";
            label2.Size = new Size(61, 25);
            label2.TabIndex = 15;
            label2.Text = "Nome";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(197, 46);
            label1.Name = "label1";
            label1.Size = new Size(84, 25);
            label1.TabIndex = 14;
            label1.Text = "Matrícula";
            // 
            // txtDataEntradaEmpresa
            // 
            txtDataEntradaEmpresa.Location = new Point(287, 154);
            txtDataEntradaEmpresa.Name = "txtDataEntradaEmpresa";
            txtDataEntradaEmpresa.Size = new Size(288, 31);
            txtDataEntradaEmpresa.TabIndex = 13;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(287, 80);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(288, 31);
            txtNome.TabIndex = 12;
            // 
            // txtSalarioHora
            // 
            txtSalarioHora.Location = new Point(287, 117);
            txtSalarioHora.Name = "txtSalarioHora";
            txtSalarioHora.Size = new Size(288, 31);
            txtSalarioHora.TabIndex = 11;
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(287, 43);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(288, 31);
            txtMatricula.TabIndex = 10;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(127, 191);
            label5.Name = "label5";
            label5.Size = new Size(154, 25);
            label5.TabIndex = 21;
            label5.Text = "Número de Horas";
            // 
            // txtNumeroHoras
            // 
            txtNumeroHoras.Location = new Point(287, 191);
            txtNumeroHoras.Name = "txtNumeroHoras";
            txtNumeroHoras.Size = new Size(288, 31);
            txtNumeroHoras.TabIndex = 20;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(161, 228);
            label6.Name = "label6";
            label6.Size = new Size(120, 25);
            label6.TabIndex = 23;
            label6.Text = "Dias de Faltas";
            // 
            // txtDiasDeFaltas
            // 
            txtDiasDeFaltas.Location = new Point(287, 228);
            txtDiasDeFaltas.Name = "txtDiasDeFaltas";
            txtDiasDeFaltas.Size = new Size(288, 31);
            txtDiasDeFaltas.TabIndex = 22;
            // 
            // frmHorista
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label6);
            Controls.Add(txtDiasDeFaltas);
            Controls.Add(label5);
            Controls.Add(txtNumeroHoras);
            Controls.Add(btnInstanciaHorista);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtDataEntradaEmpresa);
            Controls.Add(txtNome);
            Controls.Add(txtSalarioHora);
            Controls.Add(txtMatricula);
            Name = "frmHorista";
            Text = "frmHorista";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnInstanciaMensalistaComParametros;
        private Button btnInstanciaHorista;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtDataEntradaEmpresa;
        private TextBox txtNome;
        private TextBox txtSalarioHora;
        private TextBox txtMatricula;
        private Label label5;
        private TextBox txtNumeroHoras;
        private Label label6;
        private TextBox txtDiasDeFaltas;
    }
}